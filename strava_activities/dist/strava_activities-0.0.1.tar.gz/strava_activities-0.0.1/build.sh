uv build
rm dist/.gitignore

